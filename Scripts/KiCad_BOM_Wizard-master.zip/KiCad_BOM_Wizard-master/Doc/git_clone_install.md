# KiCad_BOM_Wizard via git clone

This method if for anyone who prefers to use git to clone the project.

1. clone KiCad_BOM_Wizard
```bash
git clone https://github.com/HashDefineElectronics/KiCad_BOM_Wizard.git
```
2. Install KiCad_BOM_Wizard dependencies
```bash
cd KiCad_BOM_Wizard
```
```bash
npm install
```
3. make a note of the KiCad_BOM_Wizard directory.
4. Follow the installing in this page to setup KiCad_BOM_Wizard on KiCad

  ***[Setup instructions](./setup.md)***
