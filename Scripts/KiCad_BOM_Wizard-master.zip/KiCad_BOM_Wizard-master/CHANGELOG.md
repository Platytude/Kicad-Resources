# Change log
All notable changes made on this project will be document here for convince.
Please note that this is for release code located on the `master` branch.


### [0.0.10] - Unreleased
#### Added
- The module will now attempt to install the missing dependencies if they are missing

### [0.0.9] - Unreleased
#### Added
- Added support for options files. for now on any new features will be implemented and made configurable via the options file.
- Added PDF support. the PDF generator uses html templates to create the PDF file.
- Added BOM sort settings
- Added HTML_PDF template for use with the PDF generator
### Fixed
- Fixed the issue where file names with space would break class tags
- Fixed the missing filed header class tags
