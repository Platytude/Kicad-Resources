Before contributing to the KiCad footprint libraries, it is recommended to read the [contribution guidelines](http://kicad-pcb.org/libraries/contribute).

Contributions to the KiCad libraries must meet the [KiCad Library Convetions (KLC)](http://kicad-pcb.org/libraries/klc)
